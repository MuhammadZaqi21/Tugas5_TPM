# Agent Valorant v2
## Tugas Topik 5 Praktikum TPM IF C: Fragment dan Recycleview

123180164 </br>
Muhammad Ibnu Zaqi </br>

## Screenshot
- Home (List Agent)

![Home](assets/main.png)

- Detail Agent

![Detail Agent](assets/detail.png)

- Dial Call

![Dial Call](assets/call.png)

- Result Dial Call

![Result Dial Call](assets/result-intent.png)
